using System;

namespace QuoteRunner
{
	public static class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("QuoteRunner example started.");
			// TODO: Wire up agents and run example
		}
	}
}
