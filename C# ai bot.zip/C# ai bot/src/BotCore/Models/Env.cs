namespace BotCore.Models
{
    public sealed class Env {
        public decimal? atr { get; set; }
        public decimal? volz { get; set; }
    }
}
