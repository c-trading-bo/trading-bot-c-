namespace BotCore.Models
{
    public sealed class Levels { }
}
