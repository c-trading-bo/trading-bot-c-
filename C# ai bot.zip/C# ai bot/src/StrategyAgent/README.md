# StrategyAgent

This agent coordinates the execution of all strategies (S1–S14) from BotCore. It manages candidate generation and strategy selection for the trading bot.

Implements trading strategies. Receives bar data and market context, generates trade signals for the order agent.
