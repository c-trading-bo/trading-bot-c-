using System;
using System.Collections.Generic;

namespace MarketDataAgent
{
    // BarAggregator: builds bars from trades
    public sealed class BarAggregator
    {
        // ...existing code from Core/MarketData/BarAggregator.cs...
    }
}
