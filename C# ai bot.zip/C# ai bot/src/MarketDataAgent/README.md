# MarketDataAgent

Handles all market data subscriptions, aggregation, and event dispatching. Feeds trade ticks and bars to other agents.
