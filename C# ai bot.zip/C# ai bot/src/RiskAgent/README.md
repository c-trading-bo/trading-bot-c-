# RiskAgent

Performs risk checks, R-multiple calculations, and enforces trading guardrails before orders are sent.
