namespace RiskAgent
{
    public sealed class RiskConfig
    {
        public decimal risk_per_trade { get; set; } = 100m;
    }
}
