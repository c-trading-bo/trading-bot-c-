# OrderRouterAgent

Handles order placement, routing, and fill confirmation. Ensures safe, idempotent order flow and logging.
